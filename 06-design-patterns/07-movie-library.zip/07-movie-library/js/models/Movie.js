function Movie( name, year ) {
    this.name = name;
    this.year = year;
}